package Controladores;

import java.io.*;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Conexiones.conex_MSSQL;
import HandleFileStuff.functions;

public class ctrl_personas {
    //--------------------------------
    //Create a local variables.
    //--------------------------------
    String Direc = System.getProperty("user.dir")+"\\data\\misDatos.csv";
    static functions funcs = new functions();


    public static void main(String args[]){


        //Self instance local
        ctrl_personas exec = new ctrl_personas();

        exec.print_formatFields();

    }//End main function




    //Create flat file and populate it with data
    private void createFile(int totalRows, boolean append, String Expre){
        PrintWriter pw = null;
        try{

            //Open file to write static length record
            String Director = System.getProperty("user.dir")+"\\data\\transfer.log";
            pw = new PrintWriter(new FileWriter(Director,append));

            //Create data set
            for (int i = 0; i <= 1; i++) {
                //Write record
                pw.println(Expre);

            }
            //Close flat file
            pw.close();
        } catch (Exception e) {
            //Print stack errors
            e.printStackTrace();
        }
    }//End createFile function















    //Create print all data function field by field, with format
    private void print_formatFields(){
        String datos[], Expre;
        int regi = 0;

        try {
            //Create reader object from file
            BufferedReader br = new BufferedReader(new FileReader(Direc));

            //Print each record from buffer
            while((Expre = br.readLine())!=null) {
                try {

                    conex_MSSQL insertar = new conex_MSSQL();
                    PreparedStatement insert = null;
                    ResultSet ir = null;


                    datos = Expre.split(";");
                    System.out.println("0999999999");


                    try {
                        int Provincia = 0, Sexual = 0, Politica = 0, Academica = 0;

                        insert = insertar.toConnect().prepareStatement("SELECT FROM Provincia WHERE Nombre = '"+ datos[7] + "'");
                        ir = insert.executeQuery();
                        if (ir.next()) {
                        Provincia = ir.getInt("Id_prov");
                        System.out.println(Provincia);
                        }

                        insert = insertar.toConnect().prepareStatement("SELECT FROM oSexual WHERE Descripción = '"+ datos[8] + "'");
                        ir = insert.executeQuery();
                        if (ir.next()) {
                            Sexual = ir.getInt("Id_sexual");
                            System.out.println(Sexual);
                        }
                        insert = insertar.toConnect().prepareStatement("SELECT FROM aPolitica WHERE Nombre = '"+ datos[9] + "'");
                        ir = insert.executeQuery();
                        if (ir.next()) {
                            Politica = ir.getInt("Id_poli");
                            System.out.println(Politica);
                        }
                        insert = insertar.toConnect().prepareStatement("SELECT FROM nAcademica WHERE Descripción = '"+ datos[10] + "'");
                        ir = insert.executeQuery();
                        if (ir.next()) {
                            Academica = ir.getInt("Id_acad");
                            System.out.println(Academica);
                        }

                        insert = insertar.toConnect().prepareStatement("INSERT INTO Persona (Cedula,Nombre,Apell1,Apell2,Sexo,eCivil,Nacido,Id_prov,Id_sexual,Id_poli,Id_acad,Salario) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
                        insert.setInt(1,Integer.parseInt(datos[0])); //Cedula
                        System.out.println(datos[0]);
                        insert.setString(2, datos[1]); //Nombre
                        System.out.println(datos[1]);
                        insert.setString(3, datos[2]); //Apellido1
                        System.out.println(datos[2]);
                        insert.setString(4, datos[3]); //Ap2
                        System.out.println(datos[3]);
                        insert.setString(5, datos[4]); //Sexo
                        System.out.println(datos[4]);
                        insert.setString(6, datos[5]); //eCivil
                        System.out.println(datos[5]);
                        insert.setDate(7, Date.valueOf(datos[6])); //Nacido
                        System.out.println(datos[6]);
                        insert.setInt(8,Provincia); //Provincia
                        System.out.println(datos[Provincia]);
                        insert.setInt(9,Sexual); //Sexual
                        System.out.println(datos[Sexual]);
                        insert.setInt(10,Politica); //Politica
                        System.out.println(datos[Politica]);
                        insert.setInt(11,Academica); //Academica
                        System.out.println(datos[Academica]);
                        insert.setInt(12, Integer.parseInt(datos[11]));
                        System.out.println(datos[11]);
                        insert.executeUpdate();

                    } catch (SQLException e) {



                    }


//                    System.out.printf("%d │ %-15s │ %-15s │ %-15s │ %-4s │ %-8s │ %-10s\n", Integer.parseInt(datos[0]), datos[1], datos[2], datos[3], datos[4], datos[5], datos[6]);
                    regi++;
                } catch (Exception e){
                    e.printStackTrace();
                    regi++;

                }
            }

            funcs.impLinea(95,'─');
            System.out.println("Registros impresos: "+regi);

            //Close buffer
            br.close();
        }catch (IOException ex){
            //Print stack errors
            ex.printStackTrace();
        }
    }//End print_formatFields function













    //Create print all data function field by field, with format
    private void Seek_x_Cedula(int id){
        String Expre, datos[];
        int regi = 0;

        System.out.println("Inicio: " + funcs.getTime());
        try {
            //Create reader object from file
            BufferedReader br = new BufferedReader(new FileReader(Direc));

            //Print each record from buffer
            while((Expre = br.readLine())!=null) {
                regi++;
                datos = Expre.split(";");
                if(Integer.parseInt(datos[0])==id){
                    System.out.printf("%-9s │ %-15s │ %-15s │ %-15s │ %-4s │ %-8s │ %-10s\n","Cédula","Nombre","Apellido P","Apellido M","Sexo","E. Civil","Nacido el");
                    funcs.impLinea(95,'=');
                    System.out.printf("%d │ %-15s │ %-15s │ %-15s │ %-4s │ %-8s │ %-10s\n",Integer.parseInt(datos[0]),datos[1],datos[2],datos[3],datos[4],datos[5],datos[6]);
                    funcs.impLinea(95,'─');
                    break;
                }//End of if
            }//End of while
            //Close buffer
            br.close();

            System.out.println("Registros leídos: "+regi);

        }catch (IOException ex){
            //Print stack errors
            ex.printStackTrace();
        }

        System.out.println("Final: " + funcs.getTime());
    }//End print_formatFields function

}//End dynamic_flat_file class
