package Controladores;

import Conexiones.conex_MSSQL;
import HandleFileStuff.functions;

import java.io.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ctrl_academica {
    //--------------------------------
    //Create a local variables.
    //--------------------------------
    String Direc = System.getProperty("user.dir")+"\\data\\misDatos.csv";
    static functions funcs = new functions();


    public static void main(String args[]){


        //Self instance local
        ctrl_academica exec = new ctrl_academica();

        exec.nAcademico();

    }//End main function




    //Create flat file and populate it with data
    private void createFile(int totalRows, boolean append, String Expre){
        PrintWriter pw = null;
        try{

            //Open file to write static length record
            String Director = System.getProperty("user.dir")+"\\data\\transfer.log";
            pw = new PrintWriter(new FileWriter(Director,append));

            //Create data set
            for (int i = 0; i <= 1; i++) {
                //Write record
                pw.println(Expre);

            }
            //Close flat file
            pw.close();
        } catch (Exception e) {
            //Print stack errors
            e.printStackTrace();
        }
    }//End createFile function












    //Create print all data function field by field, with format
    public void nAcademico(){
        String datos[], Expre;
        int regi = 0;

        try {
            //Create reader object from file
            BufferedReader br = new BufferedReader(new FileReader(Direc));

            //Print each record from buffer
            while((Expre = br.readLine())!=null) {
                try {

                    conex_MSSQL insertar = new conex_MSSQL();
                    PreparedStatement insert = null;
                    ResultSet ir = null;


                    datos = Expre.split(";");


                    try {
                        insert = insertar.toConnect().prepareStatement("INSERT INTO nAcademica (Descripción) VALUES (?)");
                        insert.setString(1, datos[10]); //Nombre
                        insert.executeUpdate();
                    } catch (SQLException e) {

                        System.out.println(e.getMessage());

                    }


                    regi++;
                } catch (Exception e){
                    e.printStackTrace();
                    regi++;

                }
            }

            funcs.impLinea(95,'─');
            System.out.println("Registros impresos: "+regi);

            //Close buffer
            br.close();
        }catch (IOException ex){
            //Print stack errors
            ex.printStackTrace();
        }
    }//End nAcademico function





    }//End provincias function

