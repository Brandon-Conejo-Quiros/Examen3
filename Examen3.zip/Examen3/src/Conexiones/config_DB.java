/*================================================================================================
Study Center....: Universidad Técnica Nacional
Campus..........: Pacífico (JRMP)
College career..: Ingeniería en Tecnologías de Información
Period..........: 2C-2024
Course..........: ITI-221 - Programación I
Document........: complete - connections - config_DB.java
Goals...........: Declare the connection parameters to the database
Professor.......: Jorge Ruiz (york)
Student.........:
================================================================================================*/

package Conexiones;
public class config_DB {
    public static final String Server = "127.0.0.1";
    public static final String Port = "54707";  // or 3305 for MySQL
    public static final String DB = "Examen3";
    public static final String MOTOR = "MSSQL"; // or "MySQL" for MySQL
}
