/*================================================================================================
Study Center....: Universidad Técnica Nacional
Campus..........: Pacífico (JRMP)
College career..: Ingeniería en Tecnologías de Información
Period..........: 2C-2024
Course..........: ITI-221 - Programación I
Document........: complete - connections - conex_MSSQL.java
Goals...........: Using JDBC to connect to a SQL Server database and execute a queries to:
                     - Connect to the database
                     - Apply CRUD operations
                          - Insert, Update, Delete records into / from a table
                          - Execute a query to retrieve all the records from a table
                     - Close the connection
Professor.......: Jorge Ruiz (york)
Student.........:
================================================================================================*/
package Conexiones;

// Call external libraries

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class conex_MSSQL {
    // Create the connection variables
    private static Connection conex = null;
    private static ResultSet rs = null;

    // Create the connection string
    private static String dbURL = "jdbc:sqlserver://" + config_DB.Server + ":"+ config_DB.Port +";databaseName="+ config_DB.DB +";encrypt=false";
    private static String user = "sa";
    private static String pass = "Br4nd0n_Un1";

    // Create the connection method
    public static Connection toConnect() throws SQLException {
        // Try to connect to the database
        try {
            DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
            conex = DriverManager.getConnection(dbURL, user, pass);
            if (conex != null) {
                conex.setAutoCommit(true);
                System.out.println("Connected to the database...!\n");
            }
        }catch (SQLException e){
            throw new SQLException("Error: " + e.getMessage());
        }
        return conex;
    }

    // Create the disconnection method
    public static void toDisConnect() throws SQLException{
        try {
            if (rs != null) {
                rs.close();
            }
            if (conex != null) {
                conex.close();
            }
            System.out.println("Disconnected from the database...!\n");
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public static String getUser() {
        return user;
    }

    public static void setUser(String user) {
        conex_MSSQL.user = user;
    }

    public static void setPass(String pass) {
        conex_MSSQL.pass = pass;
    }
}
