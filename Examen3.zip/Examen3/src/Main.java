import Controladores.ctrl_academica;
import Controladores.ctrl_politica;
import Controladores.ctrl_provincia;
import Controladores.ctrl_sexualidad;



public class Main {
    public static void main(String[] args) {

        ctrl_provincia execP = new ctrl_provincia();
        ctrl_sexualidad execS = new ctrl_sexualidad();
        ctrl_politica execPol = new ctrl_politica();
        ctrl_academica execA = new ctrl_academica();


        execP.provincias();
        execS.sexualidad();
        execPol.politica();
        execA.nAcademico();




    }
}